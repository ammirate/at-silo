<?php exit; ?>
1386621196
169
a:5:{s:4:"name";s:12:"eMuza_summer";s:9:"copyright";s:28:"Matti &copy; & GamesBoard.pl";s:7:"version";s:5:"3.0.7";s:14:"parse_css_file";b:1;s:8:"filetime";i:1267645320;}