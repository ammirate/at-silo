<?php exit; ?>
1386547173
162
a:5:{s:4:"name";s:15:"Artodia: Helion";s:9:"copyright";s:18:"&copy; Artodia.com";s:7:"version";s:5:"1.3.0";s:14:"parse_css_file";b:1;s:8:"filetime";i:1346023674;}