<?php exit; ?>
1386547173
208
a:6:{s:4:"name";s:15:"Artodia: Helion";s:9:"copyright";s:18:"&copy; Artodia.com";s:7:"version";s:5:"1.3.0";s:17:"template_bitfield";s:4:"lNg=";s:12:"inherit_from";s:9:"prosilver";s:8:"filetime";i:1346023674;}