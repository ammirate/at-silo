package atsilo;

public class CampoDomandaQuestionario {
	
	private int idDomandaQuestionario;
	private String tipo;
	private String descrizione;
	private String valore;
	
	public CampoDomandaQuestionario(){}

	public int getIdDomandaQuestionario() {
		return idDomandaQuestionario;
	}

	public void setIdDomandaQuestionario(int idDomandaQuestionario) {
		this.idDomandaQuestionario = idDomandaQuestionario;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getValore() {
		return valore;
	}

	public void setValore(String valore) {
		this.valore = valore;
	}
	
	
	

}


