package atsilo;

import javax.xml.crypto.Data;

public class Assenza {
	
	private Data data;
	private String codiceFiscaleBambino;
	
	public Assenza(){}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public String getCodiceFiscaleBambino() {
		return codiceFiscaleBambino;
	}

	public void setCodiceFiscaleBambino(String codiceFiscaleBambino) {
		this.codiceFiscaleBambino = codiceFiscaleBambino;
	}
	
	

}
