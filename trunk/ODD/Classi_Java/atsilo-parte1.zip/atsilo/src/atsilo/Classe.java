package atsilo;

public class Classe {
	
	private String idClasse;
	
	public Classe(){}

	public String getIdClasse() {
		return idClasse;
	}

	/**
	 * @param idClasse the idClasse to set
	 */
	public void setIdClasse(String idClasse) {
		this.idClasse = idClasse;
	}

	
	
	

}
