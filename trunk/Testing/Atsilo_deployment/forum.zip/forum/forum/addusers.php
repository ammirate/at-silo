<html>
<head>
</head>
<body>



<form method="post" action="./ucp.php?mode=register" id="register">
<label>Nome : <input type="text" tabindex="1" name="username" id="username" size="25" value="" class="inputbox autowidth" title="Nome utente"></label><br>
<label>Email : <input type="text" tabindex="2" name="email" id="email" size="25" maxlength="100" value="" class="inputbox autowidth" title="Indirizzo e-mail"></label><br>
<label>Conferma Email :<input type="password" tabindex="4" name="new_password" id="new_password" size="25" value="" class="inputbox autowidth" title="Nuova password">
<label>Password : <input type="password" tabindex="4" name="new_password" id="new_password" size="25" value="" class="inputbox autowidth" title="Nuova password"></label><br>
<label>Conferma Password : <input type="password" tabindex="5" name="password_confirm" id="password_confirm" size="25" value="" class="inputbox autowidth" title="Conferma password"></label><br>
<input type="submit" value="SPEDISCI" />
</form>


</body>
</html>