<?php if (!defined('IN_PHPBB')) exit; if ((false)) {  ?>


Configuration options.

STYLE_HEADER_LOGIN: configuration for login box
	true: login box will be shown in header.
	false: login box will be shown in menu on left side.

<?php } $this->_tpldata['DEFINE']['.']['STYLE_HEADER_LOGIN'] = TRUE; if ((false)) {  ?>


DO NOT EDIT CODE BELOW (unless you know what you are doing)

<?php } $this->_tpldata['DEFINE']['.']['STYLE_ROW_START'] = '<div class="row-wrap row-top"><span class="row-left"></span><span class="row-right"></span></div><div class="row-wrap row-left"><div class="row-wrap row-right"><div class="row-inner">'; $this->_tpldata['DEFINE']['.']['STYLE_ROW_END'] = '</div></div></div><div class="row-wrap row-bottom"><span class="row-left"></span><span class="row-right"></span></div>'; $this->_tpldata['DEFINE']['.']['STYLE_PANEL_START'] = '<div class="panel-wrap row-top"><span class="row-left"></span><span class="row-right"></span></div><div class="panel-wrap row-left"><div class="panel-wrap row-right"><div class="panel-inner">'; $this->_tpldata['DEFINE']['.']['STYLE_PANEL_END'] = '</div></div></div><div class="panel-wrap row-bottom"><span class="row-left"></span><span class="row-right"></span></div>'; $this->_tpldata['DEFINE']['.']['STYLE_POST_START'] = '<div class="post-wrap row-top"><span class="row-left"></span><span class="row-right"></span></div><div class="post-wrap row-left"><div class="post-wrap row-right"><div class="row-inner">'; $this->_tpldata['DEFINE']['.']['STYLE_POST_END'] = '</div></div></div><div class="post-wrap row-bottom"><span class="row-left"></span><span class="row-right"></span></div>'; $this->_tpldata['DEFINE']['.']['STYLE_HEADER_START'] = '<div class="header-left"><div class="header-right"><div class="header-inner">'; $this->_tpldata['DEFINE']['.']['STYLE_HEADER_END'] = '</div></div></div>'; ?>