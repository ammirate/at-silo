<?php if (!defined('IN_PHPBB')) exit; if ((false)) {  ?>

This file contains left sidebar.

Edit it as text file, not as HTML because WYSIWYG editors (such as Dreamweaver) tend to mess up phpBB template syntax.

After changing this file and uploading it on server, open your forum in browser, go to admin control panel and click "purge cache" button on control panel index.
<?php } ?>


<div class="layout-left">

	<!-- add menu from _menu.html --><?php $this->_tpl_include('_menu.html'); ?>


	<!--
	<ul class="menu">
		<li class="menu-item menu-section"><p>Sample Links</p></li>
		<li class="menu-item"><a href="#">Normal Link</a></li>
		<li class="menu-item menu-home"><a href="#">Home</a></li>
		<li class="menu-item menu-forum"><a href="#">Forum</a></li>
		<li class="menu-item menu-pm"><a href="#">Private Message</a></li>
		<li class="menu-item menu-ucp"><a href="#">User Control Panel</a></li>
		<li class="menu-item menu-users"><a href="#">Users List</a></li>
		<li class="menu-item menu-login"><a href="#">Log In</a></li>
		<li class="menu-item menu-search"><a href="#">Search</a></li>
		<li class="menu-item menu-down"><a href="#">Down Arrow</a></li>
		<li class="menu-item menu-link"><a href="#">Link</a></li>
	</ul>
	-->

</div>