Temp folder use for temporary storing of uploaded files.
